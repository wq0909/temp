pref("extensions.firebug.net.enableSites", true);
pref("extensions.firebug.pi.installed", "");
pref("extensions.firebug.pi.pluginInfo", "{}");